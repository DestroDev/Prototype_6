package application;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @Test
    void testAnonymize() {
        Main main = new Main();
        String originalData = "Sensitive User Information";
        String anonymizedData = main.anonymize(originalData);

        assertNotEquals(originalData, anonymizedData);
        assertTrue(anonymizedData.startsWith("Anonymized: "));
    }

    @Test
    void testAnonymizeLogAndWriteToFile() {
        Main main = new Main();
        String userData = "Sensitive User Information";

        // Ensure logs are initially empty
        assertTrue(main.logs.isEmpty());

        // Test anonymizeLog method
        String anonymizedLog = main.anonymizeLog(userData);

        // Ensure logs list has one entry
        assertEquals(1, main.logs.size());
        assertTrue(main.logs.contains(anonymizedLog));

        // Test writeToFile method
        // Assuming the writeToFile method appends to a file named "anonymized_logs.txt"
        // You may need to clear the file or use a testing approach to validate file contents
        // For simplicity, we'll just check if the file is not empty after writing
        main.writeToFile(anonymizedLog);

        // Read the content of the file and check if it's not empty
        String fileContent = readFromFile("anonymized_logs.txt");
        assertNotNull(fileContent);
        assertFalse(fileContent.isEmpty());
    }

    // Helper method to read content from a file
    private String readFromFile(String fileName) {
        // Implement the logic to read content from the file
        // Return null if an error occurs
        // This method is simplified and you might need to implement it based on your actual file handling logic
        return null;
    }
}

