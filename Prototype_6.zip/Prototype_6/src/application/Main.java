package application;
	
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Main extends Application {
    private List<String> logs = new ArrayList<>();

    public static void main(String[] args) {
        launch(args);
    }

    //@Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("EffortLogger V2 - Anonymity Prototype");

        // Input field for user information
        TextField userInfoField = new TextField();
        userInfoField.setPromptText("Enter user information");

        // Text area to display anonymized logs
        TextArea logArea = new TextArea();
        logArea.setPromptText("Anonymized logs will be displayed here");
        logArea.setEditable(false);

        // Button to add a new log entry
        Button addLogButton = new Button("Add Log");

        // Event handler for the Add Log button
        addLogButton.setOnAction(e -> {
            String userInfo = userInfoField.getText();
            String logEntry = anonymizeLog(userInfo);
            logArea.appendText(logEntry + "\n");
        });

        // Layout
        VBox layout = new VBox(10);
        layout.getChildren().addAll(userInfoField, addLogButton, logArea);

        Scene scene = new Scene(layout, 400, 400);
        primaryStage.setScene(scene);

        primaryStage.show();
    }

    // Implement your anonymization logic here
    private String anonymize(String data) {
        // Replace this with your actual anonymization logic
        return "Anonymized: " + data;
    }

    // Anonymize user data and log it
    private String anonymizeLog(String data) {
        String anonymizedData = anonymize(data);
        logs.add(anonymizedData);

        // Write anonymized log to a file
        writeToFile(anonymizedData);

        return anonymizedData;
    }

    // Write anonymized log to a file
    private void writeToFile(String data) {
    	try (BufferedWriter writer = new BufferedWriter(new FileWriter("anonymized_logs.txt", true))) {
    		writer.write(data + "\n");
    	} catch (IOException e) {
    		System.err.println("Error writing to file: " + e.getMessage());
    	}
    }

}
